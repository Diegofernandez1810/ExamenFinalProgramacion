package com.example.examenfinalprogramacion.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.examenfinalprogramacion.data.model.AppUser
import com.example.examenfinalprogramacion.data.repository.UserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Authorized(val uid: String) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val repo = UserRepository(FirebaseFirestore.getInstance())

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState = _authState.asStateFlow()

    fun register(email: String, password: String, fullName: String, age: Int, cardNumber: String) {
        _authState.value = AuthState.Loading
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: return@addOnSuccessListener
                val user = AppUser(uid, fullName, age, cardNumber, "user")
                viewModelScope.launch {
                    repo.createUser(user)
                    _authState.value = AuthState.Authorized(uid)
                }
            }
            .addOnFailureListener {
                _authState.value = AuthState.Error(it.message ?: "Error al registrar")
            }
    }

    fun login(email: String, password: String) {
        _authState.value = AuthState.Loading
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                _authState.value = AuthState.Authorized(it.user?.uid ?: "")
            }
            .addOnFailureListener {
                _authState.value = AuthState.Error(it.message ?: "Error al iniciar sesión")
            }
    }

    fun logout() {
        auth.signOut()
        _authState.value = AuthState.Idle
    }
}
