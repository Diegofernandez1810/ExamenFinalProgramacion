package com.example.examenfinalprogramacion.navigation

package com.example.examenfinalprogramacion.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.examenfinalprogramacion.ui.auth.LoginScreen
import com.example.examenfinalprogramacion.ui.auth.RegisterScreen
import com.example.examenfinalprogramacion.viewmodel.AuthViewModel

@Composable
fun NavGraph(navController: NavHostController, authViewModel: AuthViewModel) {
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                viewModel = authViewModel,
                onNavigateToRegister = { navController.navigate("register") },
                onLoginSuccess = { /* luego redirigiremos al menú principal */ }
            )
        }

        composable("register") {
            RegisterScreen(
                viewModel = authViewModel,
                onNavigateToLogin = { navController.popBackStack() },
                onRegisterSuccess = { /* luego redirigiremos al menú principal */ }
            )
        }
    }
}
