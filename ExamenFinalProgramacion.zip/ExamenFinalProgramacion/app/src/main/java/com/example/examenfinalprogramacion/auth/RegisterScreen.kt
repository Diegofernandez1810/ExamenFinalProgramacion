package com.example.examenfinalprogramacion.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.examenfinalprogramacion.viewmodel.AuthState
import com.example.examenfinalprogramacion.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(
    viewModel: AuthViewModel,
    onNavigateToLogin: () -> Unit,
    onRegisterSuccess: (String) -> Unit
) {
    val state by viewModel.authState.collectAsState()

    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Registro", style = MaterialTheme.typography.h5)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Nombre completo") })
            OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Edad") })
            OutlinedTextField(value = cardNumber, onValueChange = { cardNumber = it }, label = { Text("No. Tarjeta de crédito") })
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo") })
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                visualTransformation = PasswordVisualTransformation()
            )

            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                viewModel.register(email, password, fullName, age.toIntOrNull() ?: 0, cardNumber)
            }) {
                Text("Registrarse")
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { onNavigateToLogin() }) {
                Text("¿Ya tienes cuenta? Inicia sesión")
            }

            when (val s = state) {
                is AuthState.Loading -> CircularProgressIndicator()
                is AuthState.Error -> Text(s.message, color = MaterialTheme.colors.error)
                is AuthState.Authorized -> LaunchedEffect(s) { onRegisterSuccess(s.uid) }
                else -> {}
            }
        }
    }
}
