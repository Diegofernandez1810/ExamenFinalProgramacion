package com.example.examenfinalprogramacion.repository

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class User(
    val email: String = "",
    val password: String = ""
)

class UserRepository {

    private val db = FirebaseFirestore.getInstance()
    private val usersCollection = db.collection("users")

    suspend fun saveUser(user: User) {
        usersCollection.document(user.email).set(user).await()
    }

    suspend fun getUser(email: String): User? {
        val snapshot = usersCollection.document(email).get().await()
        return snapshot.toObject(User::class.java)
    }
}