package com.example.examenfinalprogramacion.model

data class AppUser(
    val uid: String = "",
    val fullName: String = "",
    val age: Int = 0,
    val cardNumber: String = "",
    val role: String = "user"
)