package com.example.examenfinalprogramacion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.compose.rememberNavController
import com.example.examenfinalprogramacion.navigation.NavGraph
import com.example.examenfinalprogramacion.viewmodel.AuthViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val authViewModel = AuthViewModel()

        setContent {
            val navController = rememberNavController()
            Surface(color = MaterialTheme.colors.background) {
                NavGraph(navController = navController, authViewModel = authViewModel)
            }
        }
    }
}
}