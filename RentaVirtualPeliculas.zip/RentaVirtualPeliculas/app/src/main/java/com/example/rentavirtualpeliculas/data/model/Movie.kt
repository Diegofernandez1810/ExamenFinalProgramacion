package com.example.rentavirtualpeliculas.data.model

data class Movie(
    val id: String = "",
    val titulo: String = "",
    val genero: String = "",
    val anio: String = "",
    val imagenUrl: String = ""
)
