package com.example.rentavirtualpeliculas.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.rentavirtualpeliculas.data.model.Movie
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.*

class MovieViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val movies: StateFlow<List<Movie>> = _movies

    init {
        loadMovies()
    }

    // 🔹 Cargar lista de películas desde Firestore
    private fun loadMovies() {
        db.collection("peliculas").get()
            .addOnSuccessListener { result ->
                val movieList = result.map { doc ->
                    Movie(
                        id = doc.id,
                        titulo = doc.getString("titulo") ?: "",
                        genero = doc.getString("genero") ?: "",
                        anio = doc.getString("anio") ?: "",
                        imagenUrl = doc.getString("imagenUrl") ?: ""
                    )
                }
                _movies.value = movieList
                Log.d("MovieViewModel", "Películas cargadas: ${movieList.size}")
            }
            .addOnFailureListener { e ->
                Log.e("MovieViewModel", "Error al cargar películas", e)
            }
    }

    // 🔹 Registrar una renta
    fun rentMovie(
        movie: Movie,
        onSuccess: () -> Unit,
        onFailure: () -> Unit
    ) {
        val user = auth.currentUser ?: return onFailure()

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val fechaInicio = sdf.format(Date())

        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 5)
        val fechaFin = sdf.format(cal.time)

        val renta = mapOf(
            "usuarioId" to user.uid,
            "peliculaId" to movie.id,
            "titulo" to movie.titulo,
            "fechaInicio" to fechaInicio,
            "fechaFin" to fechaFin
        )

        db.collection("rentas").add(renta)
            .addOnSuccessListener {
                Log.d("MovieViewModel", "Renta registrada correctamente")
                onSuccess()
            }
            .addOnFailureListener { e ->
                Log.e("MovieViewModel", "Error al registrar renta", e)
                onFailure()
            }
    }

}
