package com.example.rentavirtualpeliculas.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.rentavirtualpeliculas.data.model.Movie
import com.example.rentavirtualpeliculas.ui.viewmodel.MovieViewModel
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovieListScreen(navController: NavController, viewModel: MovieViewModel = viewModel()) {
    val movies by viewModel.movies.collectAsState()

    var dialogVisible by remember { mutableStateOf(false) }
    var dialogMessage by remember { mutableStateOf("") }

    val auth = FirebaseAuth.getInstance()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Catálogo de Películas") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Regresar")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        auth.signOut()
                        navController.navigate("login") {
                            popUpTo("home") { inclusive = true }
                        }
                    }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Cerrar Sesión")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            LazyColumn {
                items(movies) { movie ->
                    MovieCard(
                        movie = movie,
                        onRentClick = {
                            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                            val fechaInicio = sdf.format(Date())

                            val cal = Calendar.getInstance()
                            cal.add(Calendar.DAY_OF_YEAR, 5)
                            val fechaFin = sdf.format(cal.time)

                            viewModel.rentMovie(
                                movie,
                                onSuccess = {
                                    dialogMessage = "Rentaste \"${movie.titulo}\"\n\nDesde: $fechaInicio\nHasta: $fechaFin"
                                    dialogVisible = true
                                },
                                onFailure = {
                                    dialogMessage = "Error al rentar ${movie.titulo}"
                                    dialogVisible = true
                                }
                            )
                        }
                    )
                }
            }
        }

        if (dialogVisible) {
            AlertDialog(
                onDismissRequest = { dialogVisible = false },
                confirmButton = {
                    TextButton(onClick = { dialogVisible = false }) {
                        Text("Aceptar")
                    }
                },
                title = { Text("Renta confirmada") },
                text = { Text(dialogMessage) }
            )
        }
    }
}

@Composable
fun MovieCard(movie: Movie, onRentClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Image(
                painter = rememberAsyncImagePainter(model = movie.imagenUrl),
                contentDescription = movie.titulo,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(movie.titulo, style = MaterialTheme.typography.titleMedium)
            Text("Género: ${movie.genero}")
            Text("Año: ${movie.anio}")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onRentClick, modifier = Modifier.fillMaxWidth()) {
                Text("Rentar")
            }
        }
    }
}

