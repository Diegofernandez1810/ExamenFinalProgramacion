package com.example.rentavirtualpeliculas.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val age: String = "",
    val cardNumber: String = ""
)

class ProfileViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile

    // 🔹 Cargar perfil del usuario actual
    fun loadUserProfile() {
        val user = auth.currentUser
        if (user == null) {
            Log.e("ProfileViewModel", " Usuario no autenticado")
            return
        }

        db.collection("users").document(user.uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val loadedProfile = document.toObject(UserProfile::class.java)
                    if (loadedProfile != null) {
                        _userProfile.value = loadedProfile
                        Log.d("ProfileViewModel", " Perfil cargado correctamente")
                    }
                } else {
                    Log.d("ProfileViewModel", " No hay perfil existente")
                }
            }
            .addOnFailureListener { e ->
                Log.e("ProfileViewModel", " Error al cargar perfil", e)
            }
    }

    fun saveUserProfile(name: String, age: String, cardNumber: String) {
        val user = auth.currentUser
        if (user == null) {
            Log.e("ProfileViewModel", "⚠ Usuario no autenticado. No se puede guardar.")
            return
        }

        val profile = UserProfile(user.uid, name, age, cardNumber)
        db.collection("users").document(user.uid)
            .set(profile)
            .addOnSuccessListener {
                _userProfile.value = profile
                Log.d("ProfileViewModel", " Perfil guardado correctamente en Firestore")
            }
            .addOnFailureListener { e ->
                Log.e("ProfileViewModel", " Error al guardar perfil", e)
            }
    }
}
