package com.example.rentavirtualpeliculas.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class RentInfo(
    val id: String = "",
    val movieTitle: String = "",
    val userEmail: String = "",
    val startDate: String = "",
    val endDate: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(navController: NavController) {
    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    var rentList by remember { mutableStateOf(listOf<RentInfo>()) }
    var message by remember { mutableStateOf("") }

    // 🔹 Cargar el informe de rentas
    LaunchedEffect(Unit) {
        db.collection("rentas").get().addOnSuccessListener { result ->
            val list = result.documents.mapNotNull { doc ->
                RentInfo(
                    id = doc.id,
                    movieTitle = doc.getString("titulo") ?: "",
                    userEmail = doc.getString("usuarioEmail") ?: "",
                    startDate = doc.getString("fechaInicio") ?: "",
                    endDate = doc.getString("fechaFin") ?: ""
                )
            }
            rentList = list
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Informe de Rentas (Administrador)") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {

            // 🔹 Botón de cerrar sesión
            Button(
                onClick = {
                    auth.signOut()
                    navController.navigate("login") {
                        popUpTo("admin_home") { inclusive = true }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cerrar Sesión")
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (rentList.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No hay rentas registradas todavía.")
                }
            } else {
                LazyColumn {
                    items(rentList) { rent ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            elevation = CardDefaults.cardElevation(4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Película: ${rent.movieTitle}")
                                Text("Usuario: ${rent.userEmail}")
                                Text("Inicio: ${rent.startDate}")
                                Text("Fin: ${rent.endDate}")

                                Spacer(modifier = Modifier.height(8.dp))

                                // 🔹 Botón para eliminar renta
                                Button(
                                    onClick = {
                                        db.collection("rentas").document(rent.id)
                                            .delete()
                                            .addOnSuccessListener {
                                                rentList = rentList.filterNot { it.id == rent.id }
                                                message = "Renta eliminada correctamente"
                                            }
                                            .addOnFailureListener {
                                                message = "Error al eliminar renta"
                                            }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.errorContainer
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("🗑 Eliminar renta")
                                }
                            }
                        }
                    }
                }
            }

            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
