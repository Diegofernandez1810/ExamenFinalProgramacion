package com.example.rentavirtualpeliculas.ui.theme

import androidx.compose.ui.graphics.Color


val AzulPrincipal = Color(0xFF1565C0)
val AzulOscuro = Color(0xFF0D47A1)
val AzulClaro = Color(0xFF64B5F6)

val Naranja = Color(0xFFFF9800)
val NaranjaClaro = Color(0xFFFFB74D)
val NaranjaOscuro = Color(0xFFF57C00)

val FondoClaro = Color(0xFFF5F5F5)
val FondoOscuro = Color(0xFF121212)
