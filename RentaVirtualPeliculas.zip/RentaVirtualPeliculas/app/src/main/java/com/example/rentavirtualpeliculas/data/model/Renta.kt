package com.example.rentavirtualpeliculas.data.model

data class Renta(
    val titulo: String = "",
    val fechaInicio: String = "",
    val fechaFin: String = ""
)
