package com.example.rentavirtualpeliculas.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.rentavirtualpeliculas.ui.screens.AdminHomeScreen
import com.example.rentavirtualpeliculas.ui.screens.HistoryScreen
import com.example.rentavirtualpeliculas.ui.screens.LoginScreen
import com.example.rentavirtualpeliculas.ui.screens.RegisterScreen
import com.example.rentavirtualpeliculas.ui.screens.HomeScreen
import com.example.rentavirtualpeliculas.ui.screens.MovieListScreen
import com.example.rentavirtualpeliculas.ui.screens.ProfileScreen

// 🔹 Rutas de navegación
sealed class AppScreens(val route: String) {
    object Login : AppScreens("login")
    object Register : AppScreens("register")
    object Home : AppScreens("home")
    object Profile : AppScreens("profile")
    object MovieList : AppScreens("movie_list")

}

// 🔹 Controlador principal de navegación
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavGraph(navController)
}

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = AppScreens.Login.route
    ) {
        composable(route = AppScreens.Login.route) {
            LoginScreen(navController)
        }
        composable(route = AppScreens.Register.route) {
            RegisterScreen(navController)
        }
        composable(route = AppScreens.Home.route) {
            HomeScreen(navController)
        }
        composable(route = AppScreens.Profile.route) {
            ProfileScreen(navController)
        }
        composable(route = AppScreens.MovieList.route) {
            MovieListScreen(navController)
        }
        composable("history") {
            HistoryScreen(navController)
        }
        composable("admin_home") {
            AdminHomeScreen(navController)
        }
    }
}

