package com.example.rentavirtualpeliculas.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rentavirtualpeliculas.data.model.Renta
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HistoryViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val _rentas = MutableStateFlow<List<Renta>>(emptyList())
    val rentas = _rentas.asStateFlow()

    init {
        loadRentas()
    }

    fun loadRentas() {
        val userId = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            db.collection("rentas")
                .whereEqualTo("usuarioId", userId)
                .get()
                .addOnSuccessListener { result ->
                    val lista = result.documents.mapNotNull { doc ->
                        Renta(
                            titulo = doc.getString("titulo") ?: "",
                            fechaInicio = doc.getString("fechaInicio") ?: "",
                            fechaFin = doc.getString("fechaFin") ?: ""
                        )
                    }
                    _rentas.value = lista
                }
        }
    }
}
