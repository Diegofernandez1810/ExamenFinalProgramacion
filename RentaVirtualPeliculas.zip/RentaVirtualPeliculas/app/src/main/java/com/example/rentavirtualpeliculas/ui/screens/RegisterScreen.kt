package com.example.rentavirtualpeliculas.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun RegisterScreen(navController: NavController) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("usuario") } // Rol por defecto
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Registro de Usuario", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 🔹 Selector de tipo de cuenta (usuario o admin)
        Text("Selecciona el tipo de cuenta:")
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selectedRole == "usuario",
                    onClick = { selectedRole = "usuario" }
                )
                Text("Usuario")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = selectedRole == "admin",
                    onClick = { selectedRole = "admin" }
                )
                Text("Administrador")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (email.isNotEmpty() && password.isNotEmpty()) {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnSuccessListener { result ->
                            val userId = result.user?.uid ?: return@addOnSuccessListener
                            val userData = hashMapOf(
                                "email" to email,
                                "rol" to selectedRole
                            )

                            db.collection("users").document(userId).set(userData)
                                .addOnSuccessListener {
                                    message = "Registro exitoso como $selectedRole"
                                    Log.d("Registro", "Usuario registrado con rol: $selectedRole")
                                    navController.navigate("login") // Navega solo después de guardar
                                }
                                .addOnFailureListener {
                                    message = "Error al guardar usuario en Firestore"
                                }
                        }
                        .addOnFailureListener {
                            message = "Error: ${it.message}"
                        }
                } else {
                    message = "Completa todos los campos antes de continuar ⚠"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Registrarse")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(message)
    }
}



